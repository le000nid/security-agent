# ai-security-agent

Учебный SAST/DAST harness v0.2 для локальной лаборатории OWASP Juice Shop.
Nuclei и Semgrep создают общую модель Finding; опциональный DeepSeek обогащает
только уже найденные результаты.

> Используйте проект только в собственной локальной лаборатории. CLI принимает
> исключительно `localhost`, `127.0.0.1` и `juice-shop`; внешние
> домены отклоняются до запуска сканера.

## Требования

- Python 3.11+
- Docker с Compose
- Nuclei в `PATH`
- Semgrep в `PATH` для SAST/full (Linux/WSL или Docker)

Установите Nuclei по [официальной инструкции](https://docs.projectdiscovery.io/tools/nuclei/install).
Проект не содержит exploit logic и не устанавливает Nuclei автоматически.

## Быстрый старт

```bash
python -m venv .venv
# Windows PowerShell: .venv\Scripts\Activate.ps1
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
docker compose up -d juice-shop
python -m app.main --target-url http://localhost:3000 --mode dast --no-llm
python -m app.main --source-path ./app --mode sast --no-llm
python -m app.main --target-url http://localhost:3000 --source-path ./app --mode full --no-llm
```

После сканирования создаются:

- `logs/raw_nuclei.jsonl` — неизменённый JSONL Nuclei;
- `logs/raw_semgrep.json` — исходный JSON Semgrep;
- `reports/findings.json` — нормализованные находки;
- `reports/report.md` — краткий Markdown-отчёт.
- `reports/summary.json` — режим, области проверки, счётчики и краткие LLM rationale по ID.

Полные записи сканеров не включаются в Finding. `raw_output_ref` указывает
на строку JSONL или элемент JSON в logs/. Evidence содержит только выбранный
фрагмент. При успешном запуске отчёты заменяются; при ошибке CLI возвращает 1,
сохраняет raw-логи и не публикует новый успешный отчёт. Старые отчёты могут
остаться от предыдущего запуска. Не запускайте несколько сканов в одной рабочей
директории одновременно.

Остановить лабораторию:

```bash
docker compose down
```

## CLI

```text
python -m app.main --mode {dast,sast,full} [--target-url URL] [--source-path PATH] [--no-llm]
```

DAST требует URL, SAST требует путь, full требует оба. Все аргументы проверяются
до запуска сканеров. Путь должен быть существующим читаемым локальным файлом или
директорией; URL, UNC и корень файловой системы запрещены. Символические ссылки
разрешаются до проверки. HTTP HEAD preflight имеет таймаут 5 секунд, не использует
прокси и не следует редиректам; любой HTTP-ответ подтверждает доступность.

## Область сканирования

`config/nuclei/local-http.yaml` — единственный HTTP-шаблон: GET и проверка
отсутствия X-Content-Type-Options. `app/nuclei.py` явно выбирает HTTP, запрещает
редиректы, Interactsh и update checks, ограничивает частоту 5 запросами/сек.
DNS, TCP, headless, exploit/CVE-шаблоны и destructive проверки не запускаются.
`config/semgrep.yaml` содержит проверки Python debug mode и отключения проверки
TLS в JavaScript/TypeScript. Registry, metrics, autofix и builds не используются.
Сканеры получают изолированное временное окружение без пользовательских
конфигураций, ключей LLM и прокси. Это небольшой учебный набор, не полный аудит.
Имена localhost/juice-shop должны разрешаться в вашу локальную лабораторию.

## DeepSeek

Скопируйте `.env.example` в `.env` и задайте LLM_PROVIDER, LLM_MODEL,
LLM_API_KEY, LLM_BASE_URL. Уберите `--no-llm`, чтобы включить обогащение.
Поддерживаются HTTPS endpoints `https://api.deepseek.com` и `/v1`.
Это единственное разрешённое внешнее API приложения; scan targets остаются локальными.
Нормализованные finding, включая evidence и location, отправляются провайдеру;
полные raw-записи не отправляются. `--no-llm` полностью исключает LLM API.

JSON mode запрашивает объект с description, category, severity, recommendation,
rationale. Pydantic запрещает неизвестные поля, неверные severity и пустые значения.
Дополнительно отклоняются code blocks и распространённые формы shell-команд.
Этот текстовый фильтр не является универсальным распознавателем программ:
никакой LLM-текст никогда не исполняется и не передаётся в сканеры.
Инструменты модели не предоставляются. ID, title, source, tool, confidence,
location, evidence и raw_output_ref неизменны. Число finding не меняется.
Некорректный ответ, tool call, сетевой сбой или усечение ответа завершают запуск
с ошибкой; повторите с `--no-llm`. Rationale хранится в summary по ID.

## Docker agent

```bash
docker build -t ai-security-agent:0.2 .
docker compose up -d juice-shop
docker run --rm --network security-agent_default -v "${PWD}/logs:/agent/logs" -v "${PWD}/reports:/agent/reports" -v "${PWD}/app:/source:ro" ai-security-agent:0.2 --mode full --target-url http://juice-shop:3000 --source-path /source --no-llm
```

Имя сети зависит от имени Compose-проекта; пример соответствует директории
security-agent. Создайте logs/ и reports/ с правами записи для пользователя
контейнера. В контейнере localhost означает сам agent, поэтому используйте
juice-shop. Для DeepSeek добавьте `--env-file .env` перед именем image и уберите
`--no-llm`. Image включает зафиксированные версии Nuclei и Semgrep, запускается
не от root. Сборка и установка зависимостей требуют доступа к package registries.

## Тесты

```bash
pip install -r requirements-dev.txt
ruff check .
ruff format --check .
pytest -q
```

Тесты не запускают реальные сканирования: вызов Nuclei подменяется, а парсер
проверяется на локальных фикстурах.
GitHub Actions выполняет эти же проверки на Python 3.11 и 3.12.

Интеграционный smoke-check использует настоящие бинарники из image, временный
Python-файл и HTTP-сервер на loopback; внешняя сеть отключена:

```bash
docker run --rm --network none --env PYTHONPATH=/agent -v "${PWD}/tests:/checks:ro" --entrypoint python ai-security-agent:0.2 /checks/integration_smoke.py
```

Документация интеграций: [Semgrep CLI](https://docs.semgrep.dev/cli-reference),
[Nuclei](https://github.com/projectdiscovery/nuclei),
[DeepSeek JSON mode](https://api-docs.deepseek.com/guides/json_mode).
