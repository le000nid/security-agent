from pathlib import Path

from app.models import Finding
from app.report import generate_markdown_report


def test_generate_markdown_report(tmp_path: Path) -> None:
    output = tmp_path / "report.md"
    finding = Finding(
        id="headers",
        title="Missing header",
        source="DAST",
        tool="nuclei",
        raw_output_ref="logs/raw_nuclei.jsonl#L1",
        severity="info",
        location="http://localhost:3000",
    )

    generate_markdown_report([finding], "http://localhost:3000", output)

    report = output.read_text(encoding="utf-8")
    assert "# Security Scan Report" in report
    assert "Missing header" in report
    assert "Findings: **1**" in report
