# Security Scan Report

- Target: `http://localhost:3000`
- Generated (UTC): `2026-09-21T06:02:04.995006+00:00`
- Findings: **1**

## Severity summary

- info: 1

## Findings

| Severity | Title | Source / Tool | Location |
| --- | --- | --- | --- |
| info | Missing header | DAST / nuclei | http://localhost:3000 |

### Missing header



Recommendation: Review and verify this scanner finding.

Raw reference: logs/raw_nuclei.jsonl#L1
