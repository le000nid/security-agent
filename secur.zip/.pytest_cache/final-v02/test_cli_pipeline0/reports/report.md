# Security Scan Report

- Target: `http://localhost:3000`
- Generated (UTC): `2026-09-21T06:00:04.944516+00:00`
- Findings: **1**

## Severity summary

- info: 1

## Findings

| Severity | Title | Source / Tool | Location |
| --- | --- | --- | --- |
| info | Local test | DAST / nuclei | http://localhost:3000 |

### Local test



Recommendation: Review the HTTP configuration.

Raw reference: logs/raw_nuclei.jsonl#L1
