# Security Scan Report

- Target: `http://localhost:3000`
- Generated (UTC): `2026-09-21T06:00:05.208819+00:00`
- Findings: **2**

## Severity summary

- info: 1
- medium: 1

## Findings

| Severity | Title | Source / Tool | Location |
| --- | --- | --- | --- |
| medium | debug | SAST / semgrep | app.py:1 |
| info | Headers | DAST / nuclei |  |

### debug

Debug enabled

Recommendation: Review the indicated code and rule guidance.

Raw reference: logs/raw_semgrep.json#/results/0

### Headers



Recommendation: Review the HTTP configuration.

Raw reference: logs/raw_nuclei.jsonl#L1
