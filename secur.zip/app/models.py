"""Domain models used by the scanner and report generator."""

from typing import Literal

from pydantic import BaseModel, ConfigDict

Severity = Literal["info", "low", "medium", "high", "critical", "unknown"]


class Finding(BaseModel):
    """Scanner-independent finding; raw records live only in scanner logs."""

    model_config = ConfigDict(extra="forbid", frozen=True)

    id: str
    title: str
    source: Literal["SAST", "DAST"]
    tool: str
    category: str = "uncategorized"
    severity: Severity = "unknown"
    confidence: Literal["low", "medium", "high", "unknown"] = "unknown"
    location: str = ""
    evidence: str = ""
    description: str = ""
    recommendation: str = "Review and verify this scanner finding."
    raw_output_ref: str
