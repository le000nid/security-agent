"""Markdown report generation."""

import json
from collections import Counter
from datetime import datetime, timezone
from html import escape
from pathlib import Path

from app.models import Finding


def _inline(value: str) -> str:
    return escape(value).replace("|", "\\|").replace("\n", " ").replace("\r", " ")


def generate_markdown_report(
    findings: list[Finding], target_url: str, output_path: Path
) -> None:
    """Create a compact, human-readable report."""

    counts = Counter(finding.severity for finding in findings)
    generated_at = datetime.now(timezone.utc).isoformat()
    lines = [
        "# Security Scan Report",
        "",
        f"- Target: `{target_url}`",
        f"- Generated (UTC): `{generated_at}`",
        f"- Findings: **{len(findings)}**",
        "",
        "## Severity summary",
        "",
    ]
    if counts:
        lines.extend(
            f"- {severity}: {count}" for severity, count in sorted(counts.items())
        )
    else:
        lines.append("No findings were reported by the selected scanners.")

    lines.extend(["", "## Findings", ""])
    if findings:
        lines.extend(
            [
                "| Severity | Title | Source / Tool | Location |",
                "| --- | --- | --- | --- |",
            ]
        )
        for finding in findings:
            lines.append(
                "| "
                + " | ".join(
                    _inline(value)
                    for value in (
                        finding.severity,
                        finding.title,
                        f"{finding.source} / {finding.tool}",
                        finding.location,
                    )
                )
                + " |"
            )
    else:
        lines.append("No findings to display.")

    output_path.parent.mkdir(parents=True, exist_ok=True)
    for finding in findings:
        lines.extend(
            [
                "",
                f"### {_inline(finding.title)}",
                "",
                _inline(finding.description),
                "",
                "Recommendation: " + _inline(finding.recommendation),
                "",
                "Raw reference: " + _inline(finding.raw_output_ref),
            ]
        )
    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")


def save_summary(findings, mode, target, source, rationales, path: Path) -> None:
    payload = {
        "version": "0.2.0",
        "mode": mode,
        "status": "completed",
        "target_url": target,
        "source_path": str(source) if source else None,
        "total": len(findings),
        "by_source": dict(Counter(f.source for f in findings)),
        "by_severity": dict(Counter(f.severity for f in findings)),
        "llm_rationales": rationales,
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")
